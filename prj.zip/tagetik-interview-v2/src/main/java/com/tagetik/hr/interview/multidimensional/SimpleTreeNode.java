package com.tagetik.hr.interview.multidimensional;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class SimpleTreeNode implements TreeNode {

    private final String label;
    private TreeNode parent;
    private final List<TreeNode> children = new ArrayList<>();

    public SimpleTreeNode(String label) {
        this.label = label;
    }

    @Override
    public String getLabel() {
        return label;
    }

    @Override
    public Collection<TreeNode> getChildren() {
        return children;
    }

    @Override
    public TreeNode getParent() {
        return parent;
    }

    public void setParent(TreeNode parent) {
        this.parent = parent;
    }
}
