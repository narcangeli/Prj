package com.tagetik.hr.interview.multidimensional;

import java.util.Collection;

public interface TableFilter {

  /**
   * Returns a table containing only the selected columns
   */
  Table filter(Table table, Collection<String> columns);
}
