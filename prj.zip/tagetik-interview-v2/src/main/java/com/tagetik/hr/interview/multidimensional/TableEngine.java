package com.tagetik.hr.interview.multidimensional;

public interface TableEngine extends TableExecutor, TableFilter {

}
