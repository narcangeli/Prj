package com.tagetik.hr.interview.multidimensional.impl;

import com.tagetik.hr.interview.multidimensional.SimpleTreeNode;
import com.tagetik.hr.interview.multidimensional.TreeNode;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Stream;

public class TwoLevelsDimension extends AbstractDimension {

	public TwoLevelsDimension(String dimensionCode, Map<String, Set<String>> leafByNode) {
		super(dimensionCode);
		buildTree(leafByNode);
	}

	private void buildTree(Map<String, Set<String>> leafByNode) {
		createRoot();
		for (Map.Entry<String, Set<String>> entry : leafByNode.entrySet()) {
			String nodeLabel = entry.getKey();
			SimpleTreeNode node = new SimpleTreeNode(nodeLabel);
			node.setParent(root);
			root.getChildren().add(node);
			for (String leafLabel : entry.getValue()) {
				SimpleTreeNode leaf = new SimpleTreeNode(leafLabel);
				leaf.setParent(node);
				node.getChildren().add(leaf);
			}
		}
	}

	public String getMaxLength() {
		return Stream.concat(
				flatten().stream().map(node -> node.getLabel()), 
				Stream.of(root.getLabel())
				)
				.max(Comparator.comparing(s -> s.length()))
				.get();
	}

	public List<TreeNode> flatten() {
		List<TreeNode> flattenedTreeNodes = new ArrayList<>();
		for (TreeNode chile : root.getChildren()) {
			for (TreeNode leaf : chile.getChildren()) {
				flattenedTreeNodes.add(leaf);
			}
			flattenedTreeNodes.add(chile);
		}
		return flattenedTreeNodes;
	}
}