package com.tagetik.hr.interview.multidimensional.impl;

import com.tagetik.hr.interview.multidimensional.SimpleTreeNode;

import java.util.Comparator;
import java.util.Set;
import java.util.stream.Stream;

/**
 * An implementation of a dimension whose hierarchical structure is flat: the
 * possible values for the dimension are all at the same level under the root.
 */
public class FlatDimension extends AbstractDimension {

	public FlatDimension(String dimensionCode, Set<String> values) {
		super(dimensionCode);
		buildTree(values);
	}

	private void buildTree(Set<String> values) {
		if (values == null) {
			throw new IllegalArgumentException("Set of values cannot be null");
		}
		if (values.isEmpty()) {
			throw new IllegalArgumentException("Set of values cannot be empty");
		}
		createRoot();
		for (String value : values) {
			SimpleTreeNode leaf = createLeaf(value);
			root.getChildren().add(leaf);
		}
	}

	private SimpleTreeNode createLeaf(String value) {
		SimpleTreeNode leaf = new SimpleTreeNode(value);
		leaf.setParent(root);
		return leaf;
	}

	public String getMaxLength() {
		return Stream.concat(
				super.root.getChildren().stream().map(node -> node.getLabel()),
				Stream.of(super.root.getLabel())
				)
				.max(Comparator.comparing(s -> s.length()))
				.get();
	}

}
