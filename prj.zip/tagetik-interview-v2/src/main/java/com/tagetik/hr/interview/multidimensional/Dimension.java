package com.tagetik.hr.interview.multidimensional;

public interface Dimension {

    String getDimensionCode();

    TreeNode getRoot();

}
