package com.tagetik.hr.interview.multidimensional;

import java.util.Collection;

public interface TreeNode {
    String getLabel();

    Collection<TreeNode> getChildren();

    TreeNode getParent();
}
