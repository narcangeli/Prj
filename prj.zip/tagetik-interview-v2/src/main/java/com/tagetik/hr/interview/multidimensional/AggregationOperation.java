package com.tagetik.hr.interview.multidimensional;

public enum AggregationOperation {
    SUM,
    MAX,
    MIN,
    COUNT,
    AVERAGE,
}
