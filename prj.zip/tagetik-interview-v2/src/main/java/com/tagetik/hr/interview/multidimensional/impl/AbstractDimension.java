package com.tagetik.hr.interview.multidimensional.impl;

import com.tagetik.hr.interview.multidimensional.Dimension;
import com.tagetik.hr.interview.multidimensional.DimensionConstants;
import com.tagetik.hr.interview.multidimensional.SimpleTreeNode;
import com.tagetik.hr.interview.multidimensional.TreeNode;

public class AbstractDimension implements Dimension {
    private final String dimensionCode;
    protected TreeNode root;

    public AbstractDimension(String dimensionCode) {
        this.dimensionCode = dimensionCode;
    }

    @Override
    public final String getDimensionCode() {
        return dimensionCode;
    }

    @Override
    public final TreeNode getRoot() {
        return root;
    }

    void createRoot() {
        root = new SimpleTreeNode(DimensionConstants.ROOT_LABEL);
    }
}
