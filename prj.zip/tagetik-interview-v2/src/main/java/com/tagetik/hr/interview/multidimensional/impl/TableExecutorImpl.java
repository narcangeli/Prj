package com.tagetik.hr.interview.multidimensional.impl;

import java.util.ArrayList;
import java.util.List;

import com.tagetik.hr.interview.multidimensional.AggregationOperation;
import com.tagetik.hr.interview.multidimensional.Table;
import com.tagetik.hr.interview.multidimensional.TableExecutor;

public class TableExecutorImpl implements TableExecutor {

	@Override
	public double aggregate(Table table, String column, AggregationOperation operation)
			throws IllegalArgumentException {

		List<Double> values = new ArrayList<>();


		for (Table.Row row : table.getRows()) {
			values.add(row.getValue(column));
		}
		double result = 0;
		
		switch (operation) {
		
		case SUM:
			result = values
				.stream()
					.mapToDouble(d -> d.doubleValue())
					.sum();
			break;
			
		case MAX:
			result = values
				.stream()
					.mapToDouble(d -> d.doubleValue())
					.max()
					.orElseThrow(() -> new IllegalArgumentException("Illegal Argument, cannot perform " + operation + " on an empty table"));
			break;
			
		case MIN:
			result = values
				.stream()
					.mapToDouble(d -> d.doubleValue())
					.min()
					.orElseThrow(() -> new IllegalArgumentException("Illegal Argument, cannot perform " + operation + " on an empty table"));
			break;
			
		case COUNT:
			result = values
			.stream()
				.mapToDouble(d -> d.doubleValue())
				.count();
			break;
			
		case AVERAGE:
			result = values
			.stream()
				.mapToDouble(d -> d.doubleValue())
				.average()
				.orElseThrow(() -> new IllegalArgumentException("Illegal Argument, cannot perform " + operation + " on an empty table"));
		break;
		}
		

		return result;
	}

}
