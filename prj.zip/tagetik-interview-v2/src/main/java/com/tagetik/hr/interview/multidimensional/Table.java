package com.tagetik.hr.interview.multidimensional;

import java.util.Collection;
import java.util.Set;

public interface Table {

  /**
   * @return column table
   */
  Set<String> getColumns();

  /**
   * @return table rows
   */
  Collection<Row> getRows();

  interface Row {

    /**
     * Given a column return it's value
     */
    double getValue(String column);
  }
}
