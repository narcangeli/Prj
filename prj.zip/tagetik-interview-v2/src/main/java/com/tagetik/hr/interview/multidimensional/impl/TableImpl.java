package com.tagetik.hr.interview.multidimensional.impl;

import java.util.Collection;
import java.util.Map;
import java.util.Set;

import com.tagetik.hr.interview.multidimensional.Table;

public class TableImpl implements Table {

	private Set<String> columns;
	
	private Collection<Row> rows;
	
	
	public TableImpl(Set<String> columns, Collection<Row> rows) {
		this.columns = columns;
		this.rows = rows;
	}
	
	@Override
	public Set<String> getColumns() {
		return columns;
	}

	@Override
	public Collection<Row> getRows() {
		return rows;
	}
	
	public String toString() {
		
		StringBuilder builder = new StringBuilder("{");
		
		String comma = "";
		
		for (Row row : rows) {
			
			builder.append(comma);
			comma = "";
			builder.append("{");
			
			for (String col : columns) {
				double value= row.getValue(col);
				String strValue = (int)value == value ? String.valueOf((int)value) :  String.valueOf(value);
				builder.append(comma);
				comma = ", ";
				builder
				.append(col)
				.append("=")
				.append(strValue);
			}
			builder.append("}");
			comma = ", ";
		}
		
		builder.append("}");
		
		return builder.toString();
	}
	
	public static class RowImpl implements Row {

		private Map<String, Double> values;
		
		
		public RowImpl(Map<String, Double> values) {
			this.values = values;
		}
		@Override
		public double getValue(String column) {
			return values.get(column);
		}
		
	}
}
