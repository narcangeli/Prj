package com.tagetik.hr.interview.multidimensional;

public class DimensionConstants {

    public static final String ROOT_LABEL = "ROOT";
}
