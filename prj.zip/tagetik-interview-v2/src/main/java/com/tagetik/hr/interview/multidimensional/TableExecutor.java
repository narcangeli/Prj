package com.tagetik.hr.interview.multidimensional;

public interface TableExecutor {
    /**
     * Given a Table, aggregates the column based on an aggregation function.
     *
     * @param table    The data to process
     * @param column    The column to process
     * @param operation The aggregation operation
     * @return the result of the aggregation.
     *
     * @throws IllegalArgumentException If the method is invoked on an empty collection of values and the aggregation operation is
     * MAX or MIN
     */
    double aggregate(
            Table table,
            String column,
            AggregationOperation operation);
}
