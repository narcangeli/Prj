package com.tagetik.hr.interview.multidimensional.impl;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.*;

import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.tagetik.hr.interview.multidimensional.TreeNode;

public class TwoLevelsDimensionTest {

	private TwoLevelsDimension twoLevelsDimension;

	@Before
	public void init() {

		Map<String, Set<String>> tree = new HashMap<>();

		tree.put("nodeOne", new HashSet<>(Arrays.asList("LeafOne", "LeafTwo")));
		tree.put("nodeTwo", new HashSet<>(Collections.singletonList("LeafThree")));

		twoLevelsDimension = new TwoLevelsDimension("testTwoLevels", tree);
	}

	@Test
	public void rootHasNoParent() {
		assertNull(twoLevelsDimension.getRoot().getParent());
	}

	@Test
	public void leafHasParent() {
		for (TreeNode chile : twoLevelsDimension.getRoot().getChildren()) {
			for (TreeNode leaf : chile.getChildren()) {
				assertNotNull(leaf.getParent());
			}
		}
	}

	@Test
	public void leafHasNoChildren() {
		for (TreeNode chile : twoLevelsDimension.getRoot().getChildren()) {
			for (TreeNode leaf : chile.getChildren()) {
				assertTrue(leaf.getChildren().isEmpty());
			}
		}
	}
	
	@Test
	public void flattenTest() {
		assertThat(twoLevelsDimension.flatten().size(), is(5));
	}
	
	@Test
	public void rootHasNChildren() {
        assertThat(twoLevelsDimension.getRoot().getChildren().size(), is(2));
    }

	@Test
	public void getMaxLengthTest() {
		assertEquals(twoLevelsDimension.getMaxLength(), "LeafThree");
	}
}
