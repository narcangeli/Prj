package com.tagetik.hr.interview.multidimensional.impl;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import org.junit.Before;
import org.junit.Test;

import com.tagetik.hr.interview.multidimensional.AggregationOperation;
import com.tagetik.hr.interview.multidimensional.Table;

public class TableImplTest {

	private TableImpl tab;
	private Set<String> columns;
	private Collection<Table.Row> rows;

	@Before
	public void init() {
		columns = new HashSet<>(Arrays.asList("Month", "Savings"));
		Map<String, Double> aRow = new HashMap<>();
		Map<String, Double> anotherRow = new HashMap<>();
		Map<String, Double> oneMoreRow = new HashMap<>();

		aRow.put("Month", 1.0);
		aRow.put("Savings", 250.0);
		anotherRow.put("Month", 2.0);
		anotherRow.put("Savings", 80.42);
		oneMoreRow.put("Month", 3.0);
		oneMoreRow.put("Savings", 420.0);

		Table.Row rowOne = new TableImpl.RowImpl(aRow);
		Table.Row rowTwo = new TableImpl.RowImpl(anotherRow);
		Table.Row rowThree = new TableImpl.RowImpl(oneMoreRow);

		rows = new ArrayList<>();

		rows.add(rowOne);
		rows.add(rowTwo);
		rows.add(rowThree);

		tab = new TableImpl(columns, rows);
	}

	@Test
	public void toStringTest() {
		assertEquals(tab.toString(), "{{Month=1, Savings=250}, {Month=2, Savings=80.42}, {Month=3, Savings=420}}");
	}

	@Test
	public void getValueTest() {
		Table.Row row = new TableImpl.RowImpl(Collections.singletonMap("key", 10.7));
		assertEquals(row.getValue("key"), 10.7, 0.000001);
	}

	@Test
	public void aggregateTestMin() {
		TableExecutorImpl executor = new TableExecutorImpl();
		assertEquals(executor.aggregate(tab, "Savings", AggregationOperation.MIN), 80.42, 0.001);
	}

	@Test
	public void aggregateTestMax() {
		TableExecutorImpl executor = new TableExecutorImpl();
		assertEquals(executor.aggregate(tab, "Savings", AggregationOperation.MAX), 420.0, 0.001);
	}

	@Test
	public void aggregateTestSum() {
		TableExecutorImpl executor = new TableExecutorImpl();
		assertEquals(executor.aggregate(tab, "Savings", AggregationOperation.SUM), 750.42, 0.001);
	}

	@Test
	public void aggregateTestCount() {
		TableExecutorImpl executor = new TableExecutorImpl();
		assertEquals(executor.aggregate(tab, "Savings", AggregationOperation.COUNT), 3.0, 0.001);
	}

	@Test
	public void aggregateTestAverage() {
		TableExecutorImpl executor = new TableExecutorImpl();
		assertEquals(executor.aggregate(tab, "Savings", AggregationOperation.AVERAGE), 250.14, 0.001);
	}

	@Test(expected = IllegalArgumentException.class)
	public void rowsCannotBeEmptyWithAverage() {
		TableExecutorImpl executor = new TableExecutorImpl();
		Collection<Table.Row> emptyRows = new ArrayList<>();
		TableImpl emptyTab = new TableImpl(new HashSet<>(Arrays.asList("Mock")), emptyRows);
		assertEquals(executor.aggregate(emptyTab, "Savings", AggregationOperation.AVERAGE), 250.14, 0.001);
	}

	@Test(expected = IllegalArgumentException.class)
	public void rowsCannotBeEmptyWithMax() {
		TableExecutorImpl executor = new TableExecutorImpl();
		Collection<Table.Row> emptyRows = new ArrayList<>();
		TableImpl emptyTab = new TableImpl(new HashSet<>(Arrays.asList("Mock")), emptyRows);
		assertEquals(executor.aggregate(emptyTab, "Savings", AggregationOperation.MAX), 420.0, 0.001);
	}

	@Test(expected = IllegalArgumentException.class)
	public void rowsCannotBeEmptyWithMin() {
		TableExecutorImpl executor = new TableExecutorImpl();
		Collection<Table.Row> emptyRows = new ArrayList<>();
		TableImpl emptyTab = new TableImpl(new HashSet<>(Arrays.asList("Mock")), emptyRows);
		assertEquals(executor.aggregate(emptyTab, "Savings", AggregationOperation.MIN), 80.42, 0.001);
	}

}
