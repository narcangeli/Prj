package com.tagetik.hr.interview.multidimensional.impl;

import com.tagetik.hr.interview.multidimensional.TreeNode;
import org.hamcrest.Description;
import org.hamcrest.TypeSafeMatcher;

public class TreeNodeMatchers {

    private TreeNodeMatchers() {
    }

    static TypeSafeMatcher<TreeNode> treeNodeWithLabel(String label) {
        return new TypeSafeMatcher<TreeNode>() {
            @Override
            public void describeTo(Description description) {
                description.appendText(label);
            }

            @Override
            protected boolean matchesSafely(TreeNode item) {
                return label.equals(item.getLabel());
            }
        };
    }

    static TypeSafeMatcher<TreeNode> treeNodeWithParent(TreeNode parent) {
        return new TypeSafeMatcher<TreeNode>() {
            @Override
            public void describeTo(Description description) {
                description.appendText(String.valueOf(parent));
            }

            @Override
            protected boolean matchesSafely(TreeNode item) {
                return parent == item.getParent();
            }
        };
    }
}
