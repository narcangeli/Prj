package com.tagetik.hr.interview.multidimensional.impl;

import com.google.common.collect.ImmutableSet;
import com.tagetik.hr.interview.multidimensional.DimensionConstants;
import org.hamcrest.core.Every;
import org.hamcrest.core.Is;
import org.hamcrest.core.IsCollectionContaining;
import org.junit.Test;

import java.util.Collections;

import static org.hamcrest.core.Is.is;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;

public class FlatDimensionTest {

    @Test(expected = IllegalArgumentException.class)
    public void setOfValuesCannotBeNull() {
        new FlatDimension("FLAT", null);
    }

    @Test(expected = IllegalArgumentException.class)
    public void setOfValuesCannotBeEmpty() {
        new FlatDimension("FLAT", Collections.emptySet());
    }

    @Test
    public void dimensionCodeIsSet() {
        FlatDimension flatDimension = new FlatDimension("FLAT", Collections.singleton("leaf"));
        assertThat(flatDimension.getDimensionCode(), is("FLAT"));
    }

    @Test
    public void rootIsLabeledRoot() {
        FlatDimension flatDimension = new FlatDimension("FLAT", Collections.singleton("leaf"));
        assertThat(flatDimension.getRoot().getLabel(), Is.is(DimensionConstants.ROOT_LABEL));
    }

    @Test
    public void rootHasNChildren() {
        FlatDimension flatDimension = new FlatDimension("FLAT", ImmutableSet.of("a", "b"));
        assertThat(flatDimension.getRoot().getChildren().size(), is(2));
    }

    @Test
    public void rootHasNoParent() {
        FlatDimension flatDimension = new FlatDimension("FLAT", ImmutableSet.of("a", "b"));
        assertNull(flatDimension.getRoot().getParent());
    }

    @Test
    public void treeContainsAllValues() {
        FlatDimension flatDimension = new FlatDimension("FLAT", ImmutableSet.of("a", "b"));
        assertThat(flatDimension.getRoot().getChildren(), IsCollectionContaining.hasItem(TreeNodeMatchers.treeNodeWithLabel("a")));
        assertThat(flatDimension.getRoot().getChildren(), IsCollectionContaining.hasItem(TreeNodeMatchers.treeNodeWithLabel("b")));
    }

    @Test
    public void allRootChildrenHasRootAsParent() {
        FlatDimension flatDimension = new FlatDimension("FLAT", ImmutableSet.of("a", "b"));
        assertThat(flatDimension.getRoot().getChildren(), Every.everyItem(TreeNodeMatchers.treeNodeWithParent(flatDimension.getRoot())));
    }
    
    @Test 
    public void getMaxLengthTest() {
        FlatDimension flatDimension = new FlatDimension("FLAT", ImmutableSet.of("a", "b"));
        assertEquals(flatDimension.getMaxLength(), "ROOT");
    }
    
}