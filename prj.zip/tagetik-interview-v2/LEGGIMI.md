# Readme

Al candidato è richiesta la soluzione di alcuni esercizi. Alcuni esercizi richiedono
la modifica di codice esistente, altri l'implementazione di nuove funzionalità.

## Esercizio 1 - Dimension
Sia data l'interfaccia `Dimension`. Ogni dimensione ha un codice stringa associato
ed un albero (realizzato tramite l'interfaccia `TreeNode`).
L'albero rappresenta una struttura gerarchica in cui sono associati i valori possibili
per la dimensione. Ogni dimensione assume dei valori di tipo stringa.
L'albero ha una radice, etichettata con la string `ROOT`.


A titolo di esempio, si fornisce una implementazione di `Dimension` chiamata `FlatDimension`.
Una `FlatDimension` rappresenta una dimensione i cui valori sono organizzati gerarchicamente in maniera _piatta_,
ovvero tutti i valori possibili stanno sullo stesso livello dell'albero (sotto la radice).
Nella classe `FlatDimensionTest` sono collezionati alcuni test di unita' sviluppati per la classe.

### Esercizio 1.1
Implementare su `FlatDimension` un metodo

```
String getMaxLength()
```

che restituisce il codice string con il maggior numero di caratteri. Il valore `ROOT` deve essere tenuto in considerazione nel risultato.
In caso di elementi con la stessa lunghezza massima restituire un qualsiasi valore.

### Esercizio 1.2

Si consideri la classe `TwoLevelsDimension`. E' un'altra implementazione di `Dimension` che rappresenta una dimensione
in cui i valori sono organizzati in maniera gerarchica su due livelli più la radice. Il costruttore di `TwoLevelsDimension`
prende in ingresso (oltre all'identificativo della dimensione), una mappa che rappresenta la struttura gerarchica della
dimensione. Le chiavi della mappa sono le etichette dei nodi dell'albero, mentre i valori sono le etichette delle foglie
sottostanti ciascun nodo. Ad esempio data la mappa:
```
{ 
    "Italia" -> { "Lucca", "Roma" }, 
    "France" -> { "Paris", "Nice" }
}
```
la struttura dell'albero e' la seguente:

    ROOT
      - Italia
          - Lucca
          - Roma
      - France
          - Paris
          - Nice

La classe TwoLevelsDimension contiene un bug. Individuarlo e correggerlo.

### Esercizio 1.3

Implementare su `TwoLevelsDimension` un metodo

```
String getMaxLength()
```

che restituisce il codice con il maggior numero di caratteri considerando il set dei valori possibili assunti (siano essi foglie o nodi) dalla dimensione.
In caso di elementi con la stessa lunghezza massima restituire un qualsiasi valore.
Nel caso illustrato nell'esempio precedente il metodo `getMaxLength` può restituire:
```
"Italia" oppure "France"
```

### Esercizio 1.4
Scrivere una serie di test di unità per la classe `TwoLevelsDimension`

## Esercizio 2
Si consideri l'interfaccia `Table`. Essa rappresenta una struttura dati tabellare.
Le colonne sono individuate da una String e i valori possono essere solo di tipo double.

```
| Month | Savings |
|-------|---------|
| 1.0   | 250.0   |
| 2.0   | 80.0    |
| 3.0   | 420.0   |

```

### Esercizio 2.1
Fornire un implementazione di `Table`.

### Esercizio 2.2
Implementare nella classe realizzata al passo precedente il metodo `toString()` in maniera che restituisca una
stringa formattata come di seguito:
```
{ {Month=1, Savings=250}, {Month=2, Savings=80}, {Month=3, Savings=420}}
```

### Esercizio 2.3
Si consideri l'interfaccia `TableExecutor`. Fornire un implementazione di tale classe.

### Esercizio 2.4 (opzionale)
Aggiungere un valore `COUNT` all'enumerato `AggregationOperation` e adeguare l'implementazione fornita al passo precedente.

### Esercizio 2.5 (opzionale)
Aggiungere un valore `AVERAGE` all'enumerato `AggregationOperation` e adeguare l'implementazione fornita al passo precedente.
Se il metodo `aggregate` viene applicato ad una collezione vuota di valori e viene usato il tipo di aggregazione `AVERAGE`
il metodo deve sollevare un'eccezione di tipo `IllegalArgumentException`.
